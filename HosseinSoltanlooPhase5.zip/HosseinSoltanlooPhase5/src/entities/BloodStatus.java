package entities;

public enum BloodStatus {
	Muggle,
	Muggle_born,
	Half_blood,
	Pure_blood,
	Squib,
	Half_breed,
	Part_human;
}
