package entities;

public enum Grades {
	O, /* Outstanding */
	E, /* Exceeds Expectations */
	A, /* Acceptable */
	P, /* Poor */
	T; /* Troll */
}
